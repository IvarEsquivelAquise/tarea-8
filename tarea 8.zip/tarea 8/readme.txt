Descarga gratuita del c�digo fuente "Sistema de gesti�n de alquiler de viviendas"

PRIMERA Descarga

1.XAMPP

2. BLOC DE NOTAS "EDITOR DE TEXTO" ++ O TEXTO SUBLIME 3 / ETC.

3 "house_rental"

4. Descargue el archivo zip / descargue winrar

5. Extraiga el archivo y copie la carpeta "house_rental"

6.Pegue dentro del directorio ra�z / donde instala el disco local xammp C: unidad D: unidad E: pegar: (para xampp / htdocs,

7. Abra PHPMyAdmin (http: // localhost / phpmyadmin)

8. Cree una base de datos con el nombre house_rental_db

6. Importe el archivo house_rental_db.sql (incluido dentro del paquete zip en la carpeta de archivos SQL)

7.Ejecute el script http: // localhost / house_rental

**DETALLES DE REGISTRO**

Administraci�n
usuario: admin
pasar: admin123

Suscr�bete a nuestro canal de Youtube **** Soluciones coder****